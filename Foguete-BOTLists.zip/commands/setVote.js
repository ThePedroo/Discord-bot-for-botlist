const Discord = require('discord.js')
const db = require('firebase').database()
module.exports = {
  name: 'setVote',
  cooldown: 10,
  aliases: ['sv'],
  run: async(client, message, args) => {
    let erro = new Discord.MessageEmbed()
    .setDescription(`<a:yes:757568594841305149> | Desculpe ${message.author}, este servidor não é premium.`)
  }
}
const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
    name: 'setautorole',
	  description: 'Seta o autorole BOT/user.',
  	aliases: ['sau', 'setau'],
    run: async(client, message, args) => {
   let cargo = message.mentions.roles.first()
   
  let error = new Discord.MessageEmbed()
  .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author}, eu preciso da permissão gerenciar cargos para este comando.`)
  .setColor('#FF0000')
  if(!message.guild.me.hasPermission('MANAGE_ROLES')) return message.channel.send(error)
    
    let error2 = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author} você precisa da permissão gerenciar servidor para este comando.`)
    .setColor(`#FF0000`)

    if(!message.member.hasPermission("MANAGE_GUILD")) return message.channel.send(error2) 
   
   let error3 = new Discord.MessageEmbed()
   .setDescription('<a:Noo:757568484086382622> | Você precisa dizer `bot` ou `user`.')
   .setColor('#FF0000')
   
   if(!args[0] || args[0].toLowerCase() != 'bot' && args[0].toLowerCase() != 'user') return message.channel.send(error3)
   
let error4 = new Discord.MessageEmbed()
.setDescription('<a:Noo:757568484086382622> | Você precisa mencionar um cargo.')
.setColor('#FF0000')
   
   if(!cargo) return message.channel.send(error4)
   
    let error5 = new Discord.MessageEmbed()
    .setDescription('<a:Noo:757568484086382622> | Não achei esse cargo, o cargo mencionado é de outro servidor.')
    .setColor('#FF0000')
    
    if(!message.guild.roles.cache.find(a => a.id == cargo.id)) return message.channel.send(error5)
    
   if(args[0].toLowerCase() == 'bot') {
     db.ref(`Servers/${message.guild.id}/Configurações`).update({ AutoroleBot: cargo.id })
     let embed = new Discord.MessageEmbed()
     .setDescription(`<a:yes:757568594841305149> | O autorole BOT foi setado para ${cargo}.`)
     .setColor('#24FF00')
     message.channel.send(embed)
   }
   
   if(args[0].toLowerCase() == 'user') {
     db.ref(`Servers/${message.guild.id}/Configurações`).update({ AutoroleUser: cargo.id })
     let embed2 = new Discord.MessageEmbed()
     .setDescription(`<a:yes:757568594841305149> | O autorole user foi setado para ${cargo}.`)
     .setColor('#24FF00')
     message.channel.send(embed2)
   }
   
    }
}
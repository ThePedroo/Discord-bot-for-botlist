const Discord = require('discord.js')
const db = require('firebase').database()
module.exports = {
  name: 'setserverpremium',
  run: async(client, message, args) => {
    if(message.author.id != 639995261967663104) return;
    message.delete()
    if(!args[0] || args[0].toLowerCase() != 'remove' && args[0].toLowerCase() != 'set') return;
    if(!client.guilds.cache.get(args[1])) return;
    db.ref(`Servers/${args[1]}/Servidor`).update({ Premium: 'sim' })
    }
}
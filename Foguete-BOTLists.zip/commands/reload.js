const Discord = require('discord.js')
module.exports = {
   	name: 'reload',
   	description: 'Recarrega comandos.',
    aliases: ['r'],
	run: async(client, message, args) => {
    if(message.author.id != 639995261967663104) return; 
		const commandName = args[0].toLowerCase()
		const command = message.client.commands.get(commandName)
			|| message.client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName))

let error = new Discord.MessageEmbed()
.setDescription('<a:Noo:757568484086382622> | Não consegui achar esse comando ou aliases.')
.setColor('#FF0000')

		if(!command) return message.channel.send(error)
		
		delete require.cache[require.resolve(`./${command.name}.js`)]

		try {
			const newCommand = require(`./${command.name}.js`)
			message.client.commands.set(newCommand.name, newCommand)
			let embed = new Discord.MessageEmbed()
			.setThumbnail(client.user.avatarURL({dynamic: true}))
			.setDescription(`<a:yes:757568594841305149> | O comando \`${command.name}\` foi recarregado!`)
			.setColor('#24FF00')
			.setFooter('Reload', message.author.avatarURL({dynamic: true}))
			.setTimestamp()
			message.channel.send(embed)
		} catch (err) {
		  let error2 = new Discord.MessageEmbed()
		  .setDescription(`<a:Noo:757568484086382622> | Ocorreu um error ao recarregar o comando \`${command.name}\`! \`${err}\``)
		}
	}
}
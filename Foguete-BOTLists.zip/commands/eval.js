const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
const { inspect } = require('util')
module.exports = {
  name: 'eval',
  description: 'Executa evals.',
  aliases: ['e'],
  run(client, message, args) {
let error = new Discord.MessageEmbed()
    .setDescription('<a:No:740765116051750977> | Apenas minha equipe pode usar este comando.')
    .setColor('#FF0000')
    
if (!['692728615653212310', '685820186502365187', '639995261967663104', '183662027196071936'].includes(message.author.id)) return message.channel.send(error)

try {

 let info = `${inspect(eval(args.join(' '), {
                depth: 0
            }))}`

let error2 = new Discord.MessageEmbed()
.setDescription('<a:No:740765116051750977> | Não posso executar algo inexistente.')
.setColor('#FF0000')

 if(!args.join(' ')) return message.channel.send(error2)
  
function girar(array, vezes) {
  if(!Array.isArray(array)) throw new Error('Argument is not a array.')
for(let i=0;i < vezes;i++) {
array.unshift(array[array.length - 1])
array.pop()
}
return array
}

  
 let avatar = message.author.avatarURL({ dynamic: true })
 let embed = new Discord.MessageEmbed()
 .setTitle('Sucesso')
 .setThumbnail(avatar)
 .setTimestamp()
 .setDescription(`<a:Yes2:740764723179683940> | Entrada: \`\`\`${args.join(' ')}\`\`\` \n<a:foguetinho_gif:778803913495019522> | Saida: \`\`\`${info}\`\`\``)
 .setColor('#24FF00')
 .setFooter('Eval')
  
  message.channel.send(embed)
   
 } catch(err) {
   let error3 = new Discord.MessageEmbed()
   .setTitle('Error')
   .setDescription(`<a:No:740765116051750977> | Aconteceu um error! \`${err}\``)
   .setColor('#FF0000')
   
 message.channel.send(error3)
  }
 }
}
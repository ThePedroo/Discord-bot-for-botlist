const Discord = require('discord.js')
const axios = require('axios')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
  name: 'queue',
  cooldown: 10,
  aliases: ['q'],
  run: async(client, message, args) => {
db.ref(`Servers/${message.guild.id}/BOTs`).once('value').then(async (response) => {
  let erro = new Discord.MessageEmbed()
  .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, nenhum BOT está na database.`)
  .setColor('#FF0000')
  
if(!response.toJSON()) return message.channel.send(erro)
const json = response.toJSON()
const queueJson = Object.keys(json)
const queue = queueJson.map(async (id) => {
  if(!id) return;
let x = await axios.get(`https://discord.com/api/v8/users/${id}`, {
headers: { Authorization: `Bot ${process.env.TOKEN}` }
}).catch(err => {
 if(err) return;
})
if(!x) return;
const user = x.data
const bot = x.data.bot || false
if(user && bot && json[user.id]) return { 
  bot: user, 
  queue: json[id].Queue, 
  owner: json[id].Dono 
}
}).filter(a => a).filter(a => a.queue == 'sim')
let queue1 = queue[0]
if(queue1) queue1 = `1 - \`${queue1.bot.username}\` | [adicione](https://discord.com/oauth2/authorize?client_id=${queue1.bot.id}&scope=bot&permissions=0)`
if(!queue1) queue1 = 'Nenhum BOT está na queue.'

let queue2 = queue[1]
if(queue2) queue2 = `\n2 - \`${queue2.bot.username}\` | [adicione](https://discord.com/oauth2/authorize?client_id=${queue2.bot.id}&scope=bot&permissions=0)`
if(!queue2) queue2 = ''

let queue3 = queue[2]
if(queue3) queue3 = `\n3 - \`${queue3.bot.username}\` | [adicione](https://discord.com/oauth2/authorize?client_id=${queue3.bot.id}&scope=bot&permissions=0)`
if(!queue3) queue3 = ''

let queue4 = queue[3]
if(queue4) queue4 = `\n4 - \`${queue4.bot.username}\` | [adicione](https://discord.com/oauth2/authorize?client_id=${queue4.bot.id}&scope=bot&permissions=0)`
if(!queue4) queue4 = ''

let queue5 = queue[4]
if(queue5) queue5 = `\n5 - \`${queue5.bot.username}\` | [adicione](https://discord.com/oauth2/authorize?client_id=${queue5.bot.id}&scope=bot&permissions=0)`
if(!queue5) queue5 = ''

axios.get(`https://discord.com/api/v8/users/${process.env.BOTID}`, { 
headers:{ Authorization: `Bot ${process.env.TOKEN}` }
}).then(async (x) => {

let embed = new Discord.MessageEmbed()
.setThumbnail(`https://cdn.discordapp.com/avatars/${process.env.BOTID}/${x.data.avatar}.png?size=2048`)
.setDescription(`${queue1}${queue2}${queue3}${queue4}${queue5}`)
.setFooter('Queue', message.author.avatarURL({dynamic: true}))
.setTimestamp()
.setColor('#003CFF')
message.channel.send(embed)
   })
  })
 }
}
const Discord = require('discord.js') 
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
  name: 'setcargoaprovado',
  description: 'Seta o cargo que o BOT recebe quando um BOT é aprovado.',
  aliases: ['scargoa', 'setcargoa'],
  run: async(client, message, args) => {
    let cargo = message.mentions.roles.first()
    
    let error = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author} você precisa da permissão gerenciar servidor para este comando.`)
    .setColor(`#FF0000`)

    if(!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(error)
    
    let error2 = new Discord.MessageEmbed()
    .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, você precisa mencionar um cargo.`)
    .setColor('#FF0000')
    
    if(!cargo) return message.channel.send(error2)
    
     let error3 = new Discord.MessageEmbed()
    .setDescription('<a:Noo:757568484086382622> | Não achei esse cargo, o cargo mencionado é de outro servidor.')
    .setColor('#FF0000')
    
    if(!message.guild.roles.cache.find(a => a.id == cargo.id)) return message.channel.send(error3)
    
 db.ref(`Servers/${message.guild.id}/Configurações`).update({ CargoAprovado: cargo.id })
  
let embed = new Discord.MessageEmbed()
    .setDescription(`<a:Yes2:740764723179683940> | ${message.author} setou o cargo de BOTs aprovados para ${cargo}.`)
     .setColor(`#24FF00`)
  message.channel.send(message.author, embed)
  }
}
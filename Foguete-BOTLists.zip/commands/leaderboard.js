const axios = require('axios')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
  name: 'leaderboard',
  aliases: ['lb', 'rank'],
  run: async(client, message, args) => {
db.ref(`Servers/${message.guild.id}/BOTs`).once('value').then(async (response) => {
if(!response.toJSON()) {
  return axios.post(`https://discord.com/api/v8/channels/${message.channel.id}/messages`, { embed: { 
  'description': `<a:Noo:757568484086382622> | Desculpe ${message.author}, nenhum BOT está na database.`,
  'color': '16711680'} }, { headers: { Authorization: `Bot ${process.env.TOKEN}` } })
}
const json = response.toJSON()
const votosJson = Object.keys(json)
const votos = votosJson.map(id => {
const user = client.users.cache.get(id)
if(user && user.bot && json[user.id]) return { bot: user, votos: Number(json[id].Votos), owner: json[id].Dono }}).filter(a => a);
const sortedVotes = await votos.sort((a, b) => b.votos - a.votos)
let top1 = sortedVotes[0]
if(top1) top1 = `1 - \`${client.users.cache.get(top1.bot.id).tag}\` | \`${top1.votos} votos.\``
if(!top1) top1 = ''

let top2 = sortedVotes[1]
if(top2) top2 = `\n2 - \`${client.users.cache.get(top2.bot.id).tag}\` | \`${top2.votos} votos.\``
if(!top2) top2 = ''

let top3 = sortedVotes[2]
if(top3) top3 = `\n3 - \`${client.users.cache.get(top3.bot.id).tag}\` | \`${top3.votos} votos.\``
if(!top3) top3 = ''

let top4 = sortedVotes[3]
if(top4) top4 = `\n4 - \`${client.users.cache.get(top4.bot.id).tag}\` | \`${top4.votos} votos.\``
if(!top4) top4 = ''

let top5 = sortedVotes[4]
if(top5) top5 = `\n5 - \`${client.users.cache.get(top5.bot.id).tag}\` | \`${top5.votos} votos.\``
if(!top5) top5 = ''

let top6 = sortedVotes[5]
if(top6) top6 = `\n6 - \`${client.users.cache.get(top6.bot.id).tag}\` | \`${top6.votos} votos.\``
if(!top6) top6 = ''

let top7 = sortedVotes[6]
if(top7) top7 = `\n7 - \`${client.users.cache.get(top7.bot.id).tag}\` | \`${top7.votos} votos.\``
if(!top7) top7 = ''

let top8 = sortedVotes[7]
if(top8) top8 = `\n8 - \`${client.users.cache.get(top8.bot.id).tag}\` | \`${top8.votos} votos.\``
if(!top8) top8 = ''

let top9 = sortedVotes[8]
if(top9) top9 = `\n9 - \`${client.users.cache.get(top9.bot.id).tag}\` | \`${top9.votos} votos.\``
if(!top9) top9 = ''

let top10 = sortedVotes[9]
if(top10) top10 = `\n10 - \`${client.users.cache.get(top10.bot.id).tag}\` | \`${top10.votos} votos.\``
if(!top10) top10 = ''

axios.post(`https://discord.com/api/v8/channels/${message.channel.id}/messages`, { embed: { 
  'description': `${top1}${top2}${top3}${top4}${top5}${top6}${top7}${top8}${top9}${top10}`,
  'color': '15615'} }, { headers: { Authorization: `Bot ${process.env.TOKEN}` } })
})
}
} 
const axios = require('axios')
module.exports = {
  name: 'say',
  run: async(client, message, args) => {
if(!args[0]) {
  return axios.post(`https://discord.com/api/v8/channels/${message.channel.id}/messages`, { embed: { 
  'description': `<a:Noo:757568484086382622> | Desculpe ${message.author}, você deve falar algo.`,
  'color': '16711680'} }, { headers: { Authorization: `Bot ${process.env.TOKEN}` } })
}
    
    if(args.join(' ').includes('@everyone') || args.join(' ').includes('@here') || message.mentions.roles.first()) {
      return axios.post(`https://discord.com/api/v8/channels/${message.channel.id}/messages`, { embed: { 
  'description': `<a:Noo:757568484086382622> | Desculpe ${message.author}, você não pode marcar everyone, here ou um cargo.`,
  'color': '16711680'} }, { headers: { Authorization: `Bot ${process.env.TOKEN}` } })
    }
    
 axios.post(`https://discord.com/api/v8/channels/${message.channel.id}/messages`, { 'content': `${args.join(' ')}\n\n<a:foguetinho_gif:778803913495019522> | Mensagem enviada por ${message.author}.` }, { headers: { Authorization: `Bot ${process.env.TOKEN}` } })
    
  }
}
const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
  name: 'votar',
  aliases: ['v'],
  cooldown: 43200,
  run: async(client, message, args) => {
  let bot = message.mentions.users.first()
  
  let error = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Você não mencionou nenhum BOT.')
  .setColor('#FF0000')
  
  if(!bot) return message.channel.send(error)
  
  let error2 = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Você mencionou um usuário, não um BOT.')
  .setColor('#FF0000')
  
  if(!bot.bot) return message.channel.send(error2)
  
  let dono = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Dono`).once('value')
  dono = dono.val()
  
  let error3 = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Este BOT não está registrado na minha database.')
  .setColor('#FF0000')
  
  if(!dono) return message.channel.send(error3)
  
  let votos = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Votos`).once('value')
  votos = votos.val()
  
 db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}`).update({ Votos: Number(votos) + Number(1) })
 
let votos2 = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Votos`).once('value')
  votos2 = votos2.val()
 
 let descrição = 'voto'
 if(votos2 != 1) descrição = 'votos'
 
 
 let embed = new Discord.MessageEmbed()
 .setDescription(`<a:yes:757568594841305149> | Você votou no BOT ${bot}, agora ele tem ${votos2} ${descrição}!`)
 .setColor('#24FF00')
 
 message.channel.send(embed)
  }
}
const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
  name: 'wiki',
  description: 'De uma wiki ao servidor.',
  aliases: ['w'],
  run: async(client, message, args) => {
    
let log = await db.ref(`Servers/${message.guild.id}/Configurações/CanalWiki`).once('value')
     log = log.val() 
    
let error = new Discord.MessageEmbed()
     .setDescription('<a:Noo:757568484086382622> | O canal de wikis não foi setado.')
     .setColor('#FF0000')
     
if(!log) return message.channel.send(error)
    
    let error2 = new Discord.MessageEmbed()
    .setDescription('<a:Noo:757568484086382622> | Você precisa escrever algo.')
    .setColor('#FF0000')
    
    if(!args[0]) return message.channel.send(error2)
    
    let embed = new Discord.MessageEmbed()
    .setDescription('<a:yes:757568594841305149> | Sua wiki foi enviada!')
    .setColor('#24FF00')
    
    message.channel.send(embed)
    
    let embed2 = new Discord.MessageEmbed()
    .setTitle(`Wiki de ${message.author.tag}`)
    .setThumbnail(client.user.avatarURL({dynamic: true}))
    .setDescription(`\`\`\`${args.join(' ')}\`\`\`\n<a:Noo:757568484086382622> - Não gostei\n<a:yes:757568594841305149> - Gostei`)
    .setColor('#003CFF')
    .setFooter('Wiki', message.author.avatarURL({dynamic: true}))
    .setTimestamp()
    
    client.channels.cache.get(log).send(message.author, embed2).then(msg => {
      msg.react('757568594841305149')
      msg.react('757568484086382622')
    })
  }
}
const Discord = require('discord.js')
const db = require('firebase').database()
module.exports = {
  name: 'setVote',
  cooldown: 10,
  aliases: ['sv'],
  run: async(client, message, args) => {
    let bot = message.mentions.users.first()
    let premium = await db.ref(`Servers/${message.guild.id}/Servidor/Premium`).once('value')
    premium = premium.val()
    
    let error = new Discord.MessageEmbed()
    .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, este servidor não é premium.`)
    .setColor('#FF0000')
    
    if(!premium) return message.channel.send(error)
    
    let error2 = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author} você precisa da permissão gerenciar servidor para este comando.`)
    .setColor(`#FF0000`)

    if(!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(error2)
  
  let error3 = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Você não mencionou nenhum BOT.')
  .setColor('#FF0000')
  
  if(!bot) return message.channel.send(error3)
  
  let error4 = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Você mencionou um usuário, não um BOT.')
  .setColor('#FF0000')
  
  if(!bot.bot) return message.channel.send(error4)
  
  let dono = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Dono`).once('value')
  dono = dono.val()
  
  let error5 = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Este BOT não está registrado na minha database.')
  .setColor('#FF0000')
  
  if(!dono) return message.channel.send(error5)
  
  let erro6 = new Discord.MessageEmbed()
  .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, você precisa dizer um número.`)
  .setColor('#FF0000')
  
    if(!args[1] || !args[1].includes(0) && !args[1].includes(1) && !args[1].includes(2) && !args[1].includes(3) && !args[1].includes(4) && !args[1].includes(5) && !args[1].includes(6) && !args[1].includes(7) && !args[1].includes(8) && !args[1].includes(9)) return message.channel.send(erro6)
  
  db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}`).update({ Votos: args[1] })
  
  let embed = new Discord.MessageEmbed()
  .setDescription(`<a:yes:757568594841305149> | Agora o BOT ${bot} tem ${args[1]} votos.`)
  .setColor('#22FF00')
  
  message.channel.send(embed)
  }
}  
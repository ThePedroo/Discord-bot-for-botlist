const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
    name: 'setsistemakick',
  	description: 'seta o sistema de kick para on ou off',
  	aliases: ['ssk'],
    run: async(client, message, args) => {
    
  let error = new Discord.MessageEmbed()
  .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author}, eu preciso da permissão kickar membros para este comando.`)
  .setColor('#FF0000')
  if(!message.guild.me.hasPermission('KICK_MEMBERS')) return message.channel.send(error)
    
    let error2 = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author} você precisa da permissão gerenciar servidor para este comando.`)
    .setColor(`#FF0000`)

    if(!message.member.hasPermission("MANAGE_GUILD")) return message.channel.send(error2)
    
    let error3 = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author}, fale 'on' ou 'off'.`)
    .setColor(`#FF0000`)
    
    if(!args[0] || args[0].toLowerCase() != 'on' && args[0].toLowerCase() != 'off') return message.channel.send(error3)
    
    let on_off = args[0].toLowerCase().replace('on', 'sim').replace('off', 'não')

 db.ref(`Servers/${message.guild.id}/Configurações`).update({ SistemaKick: on_off })

    let embed = new Discord.MessageEmbed()
    .setDescription(`<a:Yes2:740764723179683940> | ${message.author} setou o sistema de kick automático para ${args[0].toLowerCase()}.`)
  .setColor(`#24FF00`)
  message.channel.send(message.author, embed)
  }
}
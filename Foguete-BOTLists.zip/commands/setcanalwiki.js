const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
    name: 'setcanalwiki',
  	description: 'Seta o canal de wikis.',
  	aliases: ['scw', 'setcw', 'setcanalw'],
    run: async(client, message, args) => {
    
    let canal = message.mentions.channels.first()
    
    let error = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author} você precisa da permissão gerenciar servidor para este comando.`)
    .setColor(`#FF0000`)

    if(!message.member.hasPermission("MANAGE_GUILD")) return message.channel.send(error)
    
    let error2 = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author}, mencione um canal.`)
    .setColor(`#FF0000`)
    
    if(!canal) return message.channel.send(error2)
    
    let error3 = new Discord.MessageEmbed()
    .setDescription('<a:Noo:757568484086382622> | Não achei esse canal, o canal mencionado é de outro servidor.')
    .setColor('#FF0000')
    
    if(!message.guild.channels.cache.find(a => a.id == canal.id)) return message.channel.send(error3)
    

 db.ref(`Servers/${message.guild.id}/Configurações`).update({ CanalWiki: canal.id })

    let embed = new Discord.MessageEmbed()
    .setDescription(`<a:Yes2:740764723179683940> | ${message.author} setou o canal de wikis para ${canal}.`)
  .setColor(`#24FF00`)
  message.channel.send(message.author, embed)
  }
}
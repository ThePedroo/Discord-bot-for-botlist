const Discord = require('discord.js')
module.exports = {
 name: 'invite',
 aliases: ['adicionar'],
run: async(client, message, args) => {
let embed = new Discord.MessageEmbed()
.setTitle('Me adicione!')
.setThumbnail(client.user.avatarURL({dynamic: true}))
.setDescription(`<:adicionar:783512472862064660> | Me adicione clicando **[aqui!](https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=2147483647)**`)
.setColor('#003CFF')
.setFooter('Invite', message.author.avatarURL({dynamic: true}))
.setTimestamp()
message.channel.send(message.author, embed)
 }
} 
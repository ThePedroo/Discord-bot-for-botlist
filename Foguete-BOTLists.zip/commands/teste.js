const axios = require('axios')
module.exports = {
  name: 'teste',
  run(client, message, args) {
 axios.post(`https://discord.com/api/v8/channels/${message.channel.id}/messages`, {
headers: { Authorization: `Bot ${process.env.TOKEN}` }
}).then(x => console.log(x))

  }
}
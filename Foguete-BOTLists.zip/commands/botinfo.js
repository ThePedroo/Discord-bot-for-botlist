const Discord = require('discord.js')
const config = require('../config.json')
module.exports = {
  name: 'botinfo',
  description: 'Mostra minhas informações',
  aliases: ['bi'],
  run: async(client, message, args) => {
let totalSeconds = client.uptime / 1000;
  let days = Math.floor(totalSeconds / 86400);
  let hours = Math.floor(totalSeconds / 3600);
  totalSeconds %= 3600;
  let minutes = Math.floor(totalSeconds / 60);
  let seconds = totalSeconds % 60;

  let uptime = `${days.toFixed()} dias, ${hours.toFixed()} horas, ${minutes.toFixed()} minutos, ${seconds.toFixed()} segundos.`;

    
    let embed = new Discord.MessageEmbed()
    .setTitle('BOTinfo')
    .setThumbnail(client.user.avatarURL({dynamic: true}))
    .setDescription(`<:bot:778663236265443349> | Meu nome: \`${client.user.username}\`\n📌 | Meu prefix normal: \`${config.prefix}\`\n<:owner:746060469344796855> | Meu dono: \`${client.users.cache.get('639995261967663104').tag}\`\n<a:config:739988548656169038> | Servers: \`${client.guilds.cache.size}\`\n<:usuario:779001330328403978> | Usuários: \`${client.users.cache.size}\`\n<a:Ping:779519416442290246> | Meu ping: \`${client.ws.ping}\`\n<:cpu:779506595482435644> | Meu uso de CPU: \`${(process.cpuUsage().system / 1024 / 1024).toFixed(2)}%\`\n<:ram:779508598999875594> | Meu uso de ram: \`${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)}MB\`\n<:uptime:777949157406277693> | Uptime: \`${uptime}\``)
    .setColor('#003CFF')
    .setFooter('BOTinfo', message.author.avatarURL({dynamic: true}))
    .setTimestamp()
    
    message.channel.send(embed)
  }
}
const axios = require('axios')
const Discord = require('discord.js')
module.exports = {
  name: 'docs',
  run: async(client, message, args) => {
    axios.get(`https://djsdocs.sorta.moe/v2/embed?src=stable&q=${encodeURIComponent(args)}`).then((response) => {
        if(response.data && !response.data.error) {
          let embed = new Discord.MessageEmbed()
          .setAuthor('Docs discord.js v12', 'https://discord.js.org/favicon.ico')
          .setThumbnail(client.user.avatarURL({dynamic: true}))
          .setDescription(response.data.description)
          .setFooter('Docs', message.author.avatarURL({dynamic: true}))
          .setTimestamp()
          .setColor('#003CFF')
          
          message.channel.send(embed)
        } else {
          let embed2 = new Discord.MessageEmbed()
          .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, não achei nada.`)
          .setColor('#FF0000')
          
          message.channel.send(embed2)
        }
      })
      .catch((err) => {
        console.error(err)
      })
  }
}  
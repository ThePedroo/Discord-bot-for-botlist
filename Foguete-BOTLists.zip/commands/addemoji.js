const Discord = require('discord.js')
module.exports = {
  name: 'addemoji',
  run: async(client, message, args) => {
       const REGEX = /:[^:\s]*(?:::[^:\s]*)*:/
let error = new Discord.MessageEmbed()
    .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author} você precisa da permissão gerenciar emojis para este comando.`)
    .setColor('#FF0000')
       
       if(!message.member.hasPermission('MANAGE_EMOJIS')) return message.channel.send(error)
       let error2 = new Discord.MessageEmbed()
       .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, isto não é um emoji.`)
       .setColor('#FF0000')

        if(!REGEX.test(args[0])) return message.channel.send(error2)
        
            const emojis = args[0].trim().split(':')[2].slice(0, 18)
            
     const emoji = client.emojis.cache.find(emoje => emoje.id == emojis)
   
   message.guild.emojis.create(emoji.url, emoji.name)
   
   let emoji2 = emoji.identifier
   if(!emoji2.startsWith('a:')) emoji2 = `:${emoji2}`
   
     let embed = new Discord.MessageEmbed()
     .setDescription(`<${emoji2}> | O emoji foi adicionado.`)
     .setColor('#24FF00')
     
message.channel.send(embed)
}
}
const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
    name: 'setcanalcorreio',
	  description: 'Seta o canal de correio.',
  	aliases: ['scc', 'setcc', 'setcanalc'],
    run: async(client, message, args) => {
    let channel = message.mentions.channels.first()
    
    let error = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author} você precisa da permissão gerenciar servidor para este comando.`)
    .setColor(`#FF0000`)
    
    if(!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(error)
    
    let error2 = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author}, mencione um canal.`)
   .setColor(`#FF0000`)
   
    if(!channel) return message.channel.send(error2)
    
    let error3 = new Discord.MessageEmbed()
    .setDescription('<a:Noo:757568484086382622> | Não achei esse canal, o canal mencionado é de outro servidor.')
    .setColor('#FF0000')
    
    if(!message.guild.channels.cache.find(a => a.id == channel.id)) return message.channel.send(error3)
    
  
 db.ref(`Servers/${message.guild.id}/Configurações`).update({ CanalCorreio: channel.id })
  
  
    let embed = new Discord.MessageEmbed()
    .setDescription(`<a:Yes2:740764723179683940> | ${message.author} setou o canal de correio para ${channel}.`)
     .setColor(`#24FF00`)
  message.channel.send(message.author, embed)
  }
}
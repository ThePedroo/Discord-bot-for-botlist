const Discord = require('discord.js')
const config = require('../config.json')
module.exports = {
  name: 'ping',
  run: async(client, message, args) => {
    let embed = new Discord.MessageEmbed()
    .setTitle('Ping, pong!')
    .setThumbnail(client.user.avatarURL({dynamic: true}))
    .setDescription(`Pong! Meu ping é de \`${client.ws.ping}ms\``)
    .setFooter('Ping', message.author.avatarURL({dynamic: true}))
    .setTimestamp()
    .setColor(config.azul)
    message.channel.send(embed)
  }
}
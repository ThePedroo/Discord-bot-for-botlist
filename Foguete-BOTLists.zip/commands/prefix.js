const Discord = require('discord.js')
const config = require('../config.json')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
    name: 'prefix',
 	  description: 'Muda o meu prefix.',
 	  aliases: ['p'],
run: async(client, message, args) => {
      let error3 = new Discord.MessageEmbed()
.setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, você precisa da permissão gerenciar servidor para este comando`)
.setColor('#FF0000')

if(!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(error3)  
        
let error4 = new Discord.MessageEmbed()
 .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, você precisa falar \`set\` ou \`reset\`.`)
.setColor('#FF0000')
 
 if(!args[0]) return message.channel.send(message.author, error4)
 
 if(args[0].toLowerCase() != 'set' && args[0].toLowerCase() != 'reset') return message.channel.send(message.author, error4)
 
 if(args[0].toLowerCase() == 'set') {
try {
 let output = '';
 let i = 0
 
let error4 = new Discord.MessageEmbed()
   .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, você precisa falar o prefix novo.`)
.setColor('#FF0000')

   if(!args[1]) return message.channel.send(error4)
  
  let error5 = new Discord.MessageEmbed()
.setDescription(`<a:Noo:757568484086382622> | Você pode escolhe um prefix de até 5 letras.`)
.setColor('#FF0000')
   
if(args[1].length > 5) return message.channel.send(error5)
   
    let embed = new Discord.MessageEmbed()
 .setDescription(`<:bot:778663236265443349> | Tem certeza que quer trocar o prefix por \`${args[1]}\`?`)
 .setColor('#003CFF')
 
 message.channel.send(message.author, embed)
 .then(async (msg) => {
 await msg.react('740764723179683940')
 await msg.react('740765116051750977')
 const filtro = (reaction, user) => ['Yes2', 'No'].includes(reaction.emoji.name) && user.id === message.author.id
 const coletor = msg.createReactionCollector(filtro)
 
 coletor.on('collect', r => {
 switch (r.emoji.name) {
 case 'Yes2':
 
 msg.reactions.removeAll
 msg.delete()
 let embed2 = new Discord.MessageEmbed()
 .setDescription(`<a:yes:757568594841305149> | Agora irei responder comandos com o prefix \`${args[1]}\`.`)
 .setColor('#24FF00')
 
 message.channel.send(embed2)
db.ref(`Servers/${message.guild.id}/Configurações`).update({ Prefix: args[1] })
 break;
 case 'No': 
 msg.reactions.removeAll
let embed3 = new Discord.MessageEmbed()
   .setDescription(`<a:yes:757568594841305149> | Eu irei continuar respondendo com o mesmo prefix`)
   .setColor('#24FF00')
   
 msg.delete().then(message.channel.send(embed3))
 break;
 } 
 })
 })
 } catch (err) {
   let error6 = new Discord.MessageEmbed()
   .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, um error aconteceu a executar este comado! \`${err}\``)
   .setColor('#FF0000')
   
 message.channel.send(error6).catch()
 }
 }
 
 if(args[0].toLowerCase() == 'reset') { 
try {
 let output = '';
 let i = 0
    let embed7 = new Discord.MessageEmbed()
 .setDescription('<:bot:778663236265443349> | Quer que volte ao meu prefix normal?')
 .setColor('#003CFF')
 
 message.channel.send(embed7)
 .then(async (msg) => {
 await msg.react("740764723179683940")
 await msg.react("740765116051750977")
 const filtro = (reaction, user) => ['Yes2', 'No'].includes(reaction.emoji.name) && user.id === message.author.id
 const coletor = msg.createReactionCollector(filtro)
 
 coletor.on('collect', r => {
 
 switch (r.emoji.name) {
 case 'Yes2':
 
 msg.reactions.removeAll
 msg.delete()
let embed5 = new Discord.MessageEmbed()
.setDescription(`<a:yes:757568594841305149> | Agora irei responder os comandos com meu prefix normal.`)
db.ref(`Servers/${message.guild.id}/Configurações`).update({ Prefix: config.prefix })
 message.channel.send(embed5);
 break;
 case 'No': 
 msg.reactions.removeAll
let embed6 = new Discord.MessageEmbed()
.setDescription(`<a:yes:757568594841305149> | Eu ainda irei os comandos com meu prefix.`)
 msg.delete().then(message.channel.send(embed6));
 break;
 } 
 })
 })
 } catch (err) {
let error7 = new Discord.MessageEmbed()
   .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, um error aconteceu a executar este comado! \`${err}\``)
   .setColor('#FF0000')
   
 message.channel.send(error7).catch()
 }
}
        }
}
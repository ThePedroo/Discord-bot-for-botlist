const Discord = require('discord.js')
module.exports = {
  name: 'avatar',
  cooldown: 10,
  aliases: ['av'],
  run: async(client, message, args) => {
    let menção = message.mentions.users.first()
    if(menção) menção = menção.id
  require('axios').get(`https://discord.com/api/v8/users/${menção || args[0] || message.author.id}`, { 
headers:{ Authorization: `Bot ${process.env.TOKEN}` }
}).then(a => {
  let id = a.data
  
require('axios').get(`https://discord.com/api/v8/users/${id.id}`, { 
headers:{ Authorization: `Bot ${process.env.TOKEN}` }
}).then(x => {
  let error = new Discord.MessageEmbed()
  .setDescription(`<a:Noo:757568484086382622> | O usuário ${id} (\`${x.data.username}#${x.data.discriminator}\`) não tem um avatar.`)
  .setColor('#FF0000')
  
  if(!x.data.avatar) return message.channel.send(error)
  
let formato = 'png'
if(x.data.avatar.startsWith('a_')) formato = 'gif'
let avatar = new Discord.MessageAttachment(`https://cdn.discordapp.com/avatars/${id.id}/${x.data.avatar}.${formato}?size=2048`, `avatar.${formato}`)

message.channel.send(avatar)
      })
    })
  }
}
const Discord = require('discord.js')
const config = require('../config.json')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
    name: 'help',
   	description: 'Uma lista de todos comandos.',
  	aliases: ['ajuda', 'h', 'a'],
    run: async(client, message, args) => {
 let prefix = await db.ref(`Servers/${message.guild.id}/Prefix`).once('value')
 prefix = prefix.val()
 if(!prefix) prefix = config.prefix;
 
  let user = message.author

  let embed = new Discord.MessageEmbed()
    .setTitle('Help | Ajuda')
    .setColor('#003CFF')
    .setDescription(`<:Numero1:784078330894745609> | Configuração\n<:Numero2:784078385344675870> | Verificação\n<:Numero3:784078432811352115> | Outros\n\n**[[Meu suporte]](https://discord.gg/kR8ydvQRVG)**`)
    .setImage('https://i.imgur.com/lHkGIMZ.png')
    .setFooter('Categorias', message.author.avatarURL({dynamic: true}))
    .setTimestamp()
    

  message.channel.send(embed).then(async msg => {
    await msg.react('784078330894745609').then(async r => {
      await msg.react('784078385344675870')
        await msg.react('784078432811352115')
})

    const Trec1 = (reaction, user) =>
      reaction.emoji.name === 'Numero1' && user.id === message.author.id
    const rec1 = msg.createReactionCollector(Trec1, { time: 100000 })

    const Trec2 = (reaction, user) =>
      reaction.emoji.name === 'Numero2' && user.id === message.author.id
    const rec2 = msg.createReactionCollector(Trec2, { time: 100000 })
    
    const Trec3 = (reaction, user) =>
      reaction.emoji.name === 'Numero3' && user.id === message.author.id
    const rec3 = msg.createReactionCollector(Trec3, { time: 100000 })

rec1.on('collect', async (r) => {
      let embed = new Discord.MessageEmbed()
        .setTitle('<a:config:739988548656169038> | Configuração')
        .setThumbnail(client.user.avatarURL({dynamic: true}))
        .setColor('#003CFF')
        .setTimestamp()
        .setDescription(`\`${prefix}setCanalAddbot [#canal]\` | Seta o canal de addbot.\n\`${prefix}setCanalAddbot2 [#canal]\` | seta o segundo canal de addbot.\n\`${prefix}setCanalCorreio [#canal]\` | Seta o canal de correio.\n\`${prefix}setCanalLog [#canal]\` | Seta o canal de log BOT.\n\`${prefix}setCanalWiki [#canal]\` | Seta o canal de wikis do server.\n\`${prefix}setSistemaKick [on/off]\` | Ativa, desativa o sistema de kick automático.\n\`${prefix}setAutorole [user/BOT] [@cargo]\` | Seta o autorole user ou BOT.\n\`${prefix}setCargoAprovado [@cargo]\` | Seta o cargo que o BOT ganha quando aprovado.\n\`${prefix}setCargoDeveloper [@cargo]\` | Seta o cargo que o dono do BOT ganha quando o BOT aprovado.\n\`${prefix}setCargoVerificador [@cargo]\` | Seta o cargo de verificador.\n\`${prefix}setCanalSugestão [#canal]\` | Seta o canal de sugestões.\n\`${prefix}prefix [set/reset] (prefix novo)\` | Sete, resete meu prefix.`)
        .setFooter('Configuração | [] - Obrigatório / () - Opcional', message.author.avatarURL({dynamic: true}))

        msg.edit(embed)
        r.users.remove(message.author.id)
        
    })

rec2.on('collect', async (r) => {
      let embed = new Discord.MessageEmbed()
        .setTitle('<:addbot:778663741575004181> | Verificação')
        .setThumbnail(client.user.avatarURL({dynamic: true}))
        .setColor('#003CFF')
        .setTimestamp()
        .setDescription(`\`${prefix}análise\` | Faz a análise do BOT.\n\`${prefix}delete [@bot]\` | Delete um BOT.\n\`${prefix}queue\` | Mostro a lista de BOTs não verificados.`)
        .setFooter('Verificação | [] - Obrigatório / () - Opcional', message.author.avatarURL({dynamic: true}))

        msg.edit(embed)
        r.users.remove(message.author.id)
        
    })

rec3.on('collect', async (r) => {
      let embed = new Discord.MessageEmbed()
        .setTitle('<:bot:778663236265443349> | Outros')
        .setThumbnail(client.user.avatarURL({dynamic: true}))
        .setColor('#003CFF')
        .setTimestamp()
        .setDescription(`\`${prefix}addbot\` | Adicione seu BOT.\n\`${prefix}votar [@bot]\` | Vote em algum BOT.\n\`${prefix}bot\` | Veja as informações de um BOT.\n\`${prefix}sugestão\` | Mande uma sugestão.\n\`${prefix}wiki\` | Mande uma wiki ao servidor.\n\`${prefix}botinfo\` | Mostro minhas informações.\n\`${prefix}uptime\` | Veja meu uptime.\n\`${prefix}status\` | Veja meu status.\n\`${prefix}invite\` | Me convide.\n\`${prefix}say [frase]\` | Fale algo com o Foguete.\n\`${prefix}ping\` | Mostro meu ping.\n\`${prefix}avatar (@user/ID)\` | Te mostro o avatar seu, do ID ou mencionado.`)
        .setFooter('Outros | [] - Obrigatório / () - Opcional', message.author.avatarURL({dynamic: true}))

        msg.edit(embed)
        r.users.remove(message.author.id)
        
    })

      })
   }
}
  
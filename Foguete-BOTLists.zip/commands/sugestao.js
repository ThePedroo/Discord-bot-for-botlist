const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
  name: 'sugestao',
  description: 'De uma sugestão ao servidor.',
  aliases: ['sugestão'],
  run: async(client, message, args) => {
    
let log = await db.ref(`Servers/${message.guild.id}/Configurações/CanalSugestao`).once('value')
     log = log.val() 
    
let error = new Discord.MessageEmbed()
     .setDescription('<a:Noo:757568484086382622> | O canal de sugestões não foi setado.')
     .setColor('#FF0000')
     
if(!log) return message.channel.send(error)
    
    let error2 = new Discord.MessageEmbed()
    .setDescription('<a:Noo:757568484086382622> | Você precisa escrever algo.')
    .setColor('#FF0000')
    
    if(!args[0]) return message.channel.send(error2)
    
    let embed = new Discord.MessageEmbed()
    .setDescription('<a:yes:757568594841305149> | Sua sugestão foi enviada!')
    .setColor('#24FF00')
    
    message.channel.send(embed)
    
    let embed2 = new Discord.MessageEmbed()
    .setTitle(`Sugestão de ${message.author.tag}`)
    .setThumbnail(client.user.avatarURL({dynamic: true}))
    .setDescription(`\`\`\`${args.join(' ')}\`\`\`\n<a:Noo:757568484086382622> - Não\n<a:yes:757568594841305149> - Sim`)
    .setColor('#003CFF')
    .setFooter('Sugestão', message.author.avatarURL({dynamic: true}))
    .setTimestamp()
    
    client.channels.cache.get(log).send(message.author, embed2).then(msg => {
      msg.react('757568594841305149')
      msg.react('757568484086382622')
    })
  }
}
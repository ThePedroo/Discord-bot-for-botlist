const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
     name: 'analise',
  	 description: 'Análise um BOT.',
	   aliases: ['análise', 'review'],
  run: async(client, message, args) => {
let error8 = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author} você precisa da permissão gerenciar servidor para este comando.`)
    .setColor(`#FF0000`)

    if(!message.member.hasPermission("MANAGE_GUILD")) return message.channel.send(error8)
    
let log = await db.ref(`Servers/${message.guild.id}/Configurações/CanalLog`).once('value')
     log = log.val() 
    
let error7 = new Discord.MessageEmbed()
     .setDescription('<a:Noo:757568484086382622> | Você não setou o canal de logs.')
     .setColor('#FF0000')
     
if(!log) return message.channel.send(error7)
let cargo = await db.ref(`Servers/${message.guild.id}/Configurações/CargoAprovado`).once('value')
     cargo = cargo.val()
let cargo2 = await db.ref(`Servers/${message.guild.id}/Configurações/CargoDev`).once('value')
     cargo2 = cargo2.val()
            let embed2 = new Discord.MessageEmbed()
              .setDescription('<:bot:778663236265443349> | Mencione o BOT.') 
              .setColor("#003CFF")
              message.channel.send(embed2).then(msg1 => {
let titulo = message.channel.createMessageCollector(a => a.author.id === message.author.id, {max: 1})
                .on('collect', async (a) => {
                  let bot = a.mentions.users.first()
                  
let error = new Discord.MessageEmbed()
                  .setDescription('<a:Noo:757568484086382622> | Você precisa mencionar um BOT.')
                  .setColor('#FF0000')
                  
          if(!a.mentions.users.first()) return message.channel.send(error)
                  
let dono = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Dono`).once('value')
dono = dono.val()
  
  let error6 = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Este BOT não está registrado na minha database.')
  .setColor('#FF0000')
  
  if(!dono) return message.channel.send(error6)
  
            let error2 = new Discord.MessageEmbed()
            .setDescription('<a:Noo:757568484086382622> | Você mencionou um usuário, não um BOT.')
            .setColor('#FF0000')
                  
          if(!a.mentions.users.first().bot) return message.channel.send(error2)
            
let prefix = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Prefix`).once('value')
prefix = prefix.val()
            
let user = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Dono`).once('value')
  user = user.val()
                  
          let embed4 = new Discord.MessageEmbed()
            .setDescription('<a:processing:756314723560980560> | O BOT foi aprovado ou reprovado?')
              .setColor("#003CFF")
            message.channel.send(embed4).then(msg3 => {
let footer = message.channel.createMessageCollector(c => c.author.id === message.author.id, {max: 1})
                .on('collect', c => {
               let ar = c.content
               
               let error5 = new Discord.MessageEmbed()
               .setDescription('<a:Noo:757568484086382622> | Você precisa falar reprovado ou aprovado.')
               .setColor('#FF0000')
               
               if(ar.toLowerCase() != "aprovado" && ar.toLowerCase() != "reprovado") return message.channel.send(error5) 
               
               let embed5 = new Discord.MessageEmbed()
          .setDescription('<:Info:772480355293986826> | Adicione uma nota, digite \'sem\' para não adicionar uma nota.')
                  .setColor("#003CFF") 
          message.channel.send(embed5).then(msg3 => {
              let descrição = message.channel.createMessageCollector(d => d.author.id === message.author.id, {max: 1})
                .on('collect', d => {
                  let nota = d.content
              
              let embed6 = new Discord.MessageEmbed()
              .setDescription('<a:yes:757568594841305149> | A análise foi enviada com sucesso.')
              .setColor('#24FF00')
              message.channel.send(embed6)
          
              let titulo2 = `\n**<:Info:772480355293986826> | Nota:\n **\`\`\`${nota}\`\`\``
              if(nota.toLowerCase() == 'sem') titulo2 = ''
     
              let emoji = ''
              if(ar.toLowerCase() == 'aprovado') {
              emoji = '<:addbot:778663741575004181>'
           message.guild.members.cache.get(bot.id).setNickname(`[ ${prefix} ] ${bot.username}`)
    if(cargo) { message.guild.members.cache.get(bot.id).roles.add(cargo) }
    if(cargo2) { message.guild.members.cache.get(user).roles.add(cargo2) }
    }
              
              if(ar.toLowerCase() == 'reprovado') emoji = '<:KickBot:778670531960242178>'
              
        let analise = message.guild.channels.cache.get(log)
        
                  let embed = new Discord.MessageEmbed()
                    .setTitle(`Análise`)
                    .setThumbnail(client.user.avatarURL({dynamic: true}))
                    .setDescription(`**<:bot:778663236265443349> | BOT:**\n\`\`\`${bot.tag}\`\`\`\n**<:Developer:779008662429499403> | Developer:**\n\`\`\`${client.users.cache.get(user).tag}\`\`\`\n**${emoji} | Aprovado ou reprovado?**\n\`\`\`${ar}\`\`\`${titulo2}\n**<a:STAFF:779009648207986719> | ${ar} por:**\n\`\`\`${message.author.tag}\`\`\``)
                  .setColor("#003CFF")
             analise.send(`<@!${user}>`, embed)
             
             db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}`).update({ Queue: 'não' })
             
               })
              })
             })
            })      
           })
          })
         }
        }
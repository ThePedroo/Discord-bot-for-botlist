const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
  name: 'bot',
  aliases: ['info'],
  run: async(client, message, args) => {
  let bot = message.mentions.users.first()
  
  let error = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Você não mencionou nenhum BOT.')
  .setColor('#FF0000')
  
  if(!bot) return message.channel.send(error)
  
  let error2 = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Você mencionou um usuário, não um BOT.')
  .setColor('#FF0000')
  
  if(!bot.bot) return message.channel.send(error2)
  
  let dono = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Dono`).once('value')
  dono = dono.val()
  
  let error3 = new Discord.MessageEmbed()
  .setDescription('<a:Noo:757568484086382622> | Este BOT não está registrado na minha database. (a database foi organizada denovo.)')
  .setColor('#FF0000')
  
  if(!dono) return message.channel.send(error3)
let info = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Info`).once('value')
info = info.val()
let prefix = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Prefix`).once('value')
prefix = prefix.val() 
let votos = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Votos`).once('value')
votos = votos.val()
let linguagem = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Linguagem`).once('value')
linguagem = linguagem.val()
let emoji = '<:nodejs:780546909029924894>'
if(linguagem == 'python') emoji = '<:Pyton:786351041251246100>'
if(linguagem == 'dbd') emoji = '<:Dbd:786350955490312233>'
  let embed = new Discord.MessageEmbed()
  .setTitle('BOTinfo')
  .setThumbnail(client.user.avatarURL({dynamic: true}))
  .setDescription(`<:owner:746060469344796855> | Dono do bot:\n\`${client.users.cache.get(dono).tag}\`/\`${dono}\`\n📌 | Prefix:\n\`${prefix}\`\n${emoji} | Linguagem:\n\`${linguagem.replace('javascript', 'JavaScript').replace('python', 'Python').replace('dbd', 'DBD')}\`\n<:voto:786350274045280279> | Votos:\n\`${votos}\`\n<:Info:772480355293986826> | Info\n\`${info}\``)
  .setColor('#003CFF')
  .setFooter('Bot')
  .setTimestamp()
  
  message.channel.send(message.author, embed)
  }
}   
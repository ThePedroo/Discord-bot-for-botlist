const Discord = require('discord.js')
const firebase = require('firebase')
const db = firebase.database()
module.exports = {
  name: 'delete',
  description: 'Delete um BOT.',
  aliases: ['del'],
run: async(client, message, args) => {
  let member = message.mentions.users.first()
  
  let error = new Discord.MessageEmbed()
  .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author}, eu preciso da permissão kickar membros para este comando.`)
  .setColor('#FF0000')
  if(!message.guild.me.hasPermission('KICK_MEMBERS')) return message.channel.send(error)
  
  let error2 = new Discord.MessageEmbed()
    .setDescription(`<a:No:740765116051750977> | Desculpe ${message.author} você precisa da permissão gerenciar servidor e kickar membros para este comando.`)
    .setColor(`#FF0000`)
if(!message.member.hasPermission("KICK_MEMBERS") || !message.member.hasPermission("MANAGE_GUILD")) return message.channel.send(error2)
    
let error3 = new Discord.MessageEmbed()
.setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, mencione um bot.`)
.setColor("#FF0000")
if(!member) return message.channel.send(error3)

let error4 = new Discord.MessageEmbed()
.setDescription(`<a:No:757568484086382622> | Desculpe ${message.author}, você mencionou um usuário, mencione um membro.`)
.setColor('#FF0000')
if(!member.bot) return message.channel.send(error4)

    let error5 = new Discord.MessageEmbed()
    .setDescription("<a:Noo:757568484086382622> | Oops! parece que eu não consigo kickar esse BOT! coloque o cargo com meu nome no topo para que possa deletar esse bot")
    .setColor("#FF0000")
    
  //  if(!member.kickable) return message.channel.send(error5)        
   message.mentions.members.first().kick({ reason: "BOT deletado." })
    
    let embed = new Discord.MessageEmbed()
    .setThumbnail(client.user.avatarURL({dynamic: true}))
.setDescription(`O BOT ${member.tag} foi deletado e kickado do server!\n\nFoi um engano? **[Adicione novamente.](https://discord.com/oauth2/authorize?client_id=${member.id}&scope=bot&permissions=37080193)**`)
    .setColor("#24FF00")
    .setFooter('Delete', message.author.avatarURL({dynamic: true}))
    .setTimestamp()
    
message.channel.send(message.author, embed)
let dono = await db.ref(`Servers/${message.guild.id}/${member.id}/Dono`).once('value')
dono = dono.val()
    if(dono) {
         db.ref(`Servers/${message.guild.id}/BOTs/${member.id}`).set(null)
         db.ref(`Servers/${message.guild.id}/Usuários/${dono}`).set(null)
       }
    }
  } 

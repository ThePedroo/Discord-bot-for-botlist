const Discord = require('discord.js')
module.exports = {
    name: 'status',
  	description: 'Mostra meu status.',
  	aliases: ['s'],
    run(client, message, args) {
  let embed = new Discord.MessageEmbed()
  .setTitle("STATUS")
  .setThumbnail(client.user.avatarURL({dynamic: true}))
  .setDescription(`**<:cpu:779506595482435644> | CPU**\n\`[${(process.cpuUsage().system / 1024 / 1024).toFixed(2)}%/100%]\`\n**<:ram:779508598999875594> | Ram**\n\`[${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)}MB/1Gb]\``)
   .setColor("#003CFF")
   .setFooter('Status', message.author.avatarURL({dynamic: true}))
   .setTimestamp()
   
  message.channel.send(embed)
}
}
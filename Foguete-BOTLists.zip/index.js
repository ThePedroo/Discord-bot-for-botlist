const express = require('express')
const axios = require('axios')
const app = express()
const Discord = require('discord.js') 
const client = new Discord.Client()
const config = require('./config.json')
const cooldowns = new Discord.Collection()
const fs = require('fs')
const { database } = require('firebase/app')
const firebase = require('firebase/app')
require('firebase/database')

app.get('/', (request, response) => {
  const ping = new Date()
  ping.setHours(ping.getHours() - 3)
  console.log(`[ \u001b[92mSISTEMA\u001b[39m ] Ping recebido às ${ping.getUTCHours()} horas, ${ping.getUTCMinutes()} minutos, ${ping.getUTCSeconds()} segundos.`)
  response.sendStatus(200)
})

app.listen(process.env.PORT)

const firebaseConfig = {
  apiKey: process.env.apiKey,
  authDomain: process.env.authDomain,
  databaseURL: process.env.databaseURL,
  projectId: process.env.projectId,
  storageBucket: process.env.storageBucket 
}

firebase.initializeApp(firebaseConfig)
  
 const db = firebase.database()

client.commands = new Discord.Collection();

const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
	const command = require(`./commands/${file}`);
	client.commands.set(command.name, command);
}

client.login(process.env.TOKEN)

client.on('message', async (message) => {
if(message.channel.type == 'dm') {
if(message.author.bot) return;
let logDM = client.channels.cache.get('766424056386813952')
let embed = new Discord.MessageEmbed()
.setAuthor(message.author.tag + ' disse:', message.author.avatarURL({dynamic: true}))
.setDescription(`${message.content}`)
.setColor(config.azul)
.setFooter('LogDM')
.setTimestamp()
logDM.send(embed)
}
    
     if(message.channel.type == 'dm') return;
   let prefix = await db.ref(`Servers/${message.guild.id}/Configurações/Prefix`).once('value')
     prefix = prefix.val()
     if(!prefix) {
       prefix = config.prefix;
db.ref(`Servers/${message.guild.id}/Configurações`).update({ Prefix: config.prefix })
     }
     
db.ref(`Servers/${message.guild.id}/Servidor`).update({ Nome: message.guild.name })
    
  
if(message.content.startsWith(`<@${client.user.id}>`) || message.content.startsWith(`<@!${client.user.tag}>`)) {
    if(message.content.endsWith(`<@${client.user.id}>`) || message.content.endsWith(`<@!${client.user.id}>`)) {
        let embed = new Discord.MessageEmbed()
        .setTitle('Olá!')
        .setThumbnail(client.user.avatarURL({dynamic: true}))
        .setDescription(`Olá ${message.author}! Meu prefix é \`${prefix}\``)
        .setFooter('Menção', message.author.avatarURL({dynamic: true}))
        .setTimestamp()
    message.channel.send(message.author, embed)
    }
 }
 
    if(!message.content.startsWith(prefix) || message.author.bot) return;
    
if(message.content.startsWith(prefix)) {
      let c = message.content.toLowerCase().replace(prefix, "")
 if(c.startsWith('addbot')) {
   if(message.guild.me.hasPermission('MANAGE_MESSAGES')) { message.delete() }
    let addbot = await db.ref(`Servers/${message.guild.id}/Configurações/CanalAddbot`).once('value')
     addbot = addbot.val()
    let addbot2 = await db.ref(`Servers/${message.guild.id}/Configurações/CanalAddbot2`).once('value')
     addbot2 = addbot2.val()
let correio = await db.ref(`Servers/${message.guild.id}/Configurações/CanalCorreio`).once('value')
     correio = correio.val()
    let log = await db.ref(`Servers/${message.guild.id}/Configurações/CanalLog`).once('value')
     log = log.val()
     let texto = ''
     if(addbot2) texto = `<#${addbot2}>`
     if(addbot) texto = `<#${addbot}>`
     if(addbot && addbot2) texto = `<#${addbot}> ou <#${addbot2}>`
    
   let error = new Discord.MessageEmbed()
   .setDescription('<a:Noo:757568484086382622> | O canal de addbot não foi setado.')
   .setColor('#FF0000')
   if(!addbot && !addbot2) return message.channel.send(error).then(msg => msg.delete({timeout: 5000}))
   
let error2 = new Discord.MessageEmbed()
     .setDescription('<a:Noo:757568484086382622> | O canal de logs não foi setado.')
     .setColor('#FF0000')
   if(!log) return message.channel.send(error2).then(msg => msg.delete({timeout: 5000}))
   
let error3 = new Discord.MessageEmbed()
   .setDescription('<a:Noo:757568484086382622> | O canal de correio não foi setado.')
   .setColor('#FF0000')
   if(!correio) return message.channel.send(error3).then(msg => msg.delete({timeout: 5000}))
   
   let error4 = new Discord.MessageEmbed()
   .setDescription(`<a:Noo:757568484086382622> | Você só pode executar este comando no ${texto}.`)
   .setColor('#FF0000')
    if(message.channel.id != addbot && message.channel.id != addbot2) return message.channel.send(error4).then(msg => msg.delete({timeout: 5000}))
    
    let error5 = new Discord.MessageEmbed()
    .setDescription('<a:Noo:757568484086382622> | Você já tem um BOT neste servidor.')
    .setColor('#FF0000')
    
    let dev = await db.ref(`Servers/${message.guild.id}/Usuários/${message.author.id}/Dev`).once('value')
    dev = dev.val()
    if(dev == 'sim') return message.channel.send(error5).then(msg => msg.delete({timeout: 5000}))
    
 try {
let embed = new Discord.MessageEmbed()
  .setTitle('Addbot!')
  .setColor("#003CFF")
  .setDescription(`⚙ | ${message.author}, Confira sua DM`)
message.channel.send(embed).then(msg => msg.delete({timeout: 5000}))
   
 let embed2 = new Discord.MessageEmbed()
 .setDescription('<a:yes:757568594841305149> | Responda as perguntas, caso algum erro aconteça, [entre em meu suporte.](https://discord.gg/kR8ydvQRVG)')
 .setColor('#003CFF')
message.author.send(embed2)
} catch(err) {
  let erro6 = new Discord.MessageEmbed()
  .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, Sua DM está privada, abra para que possa continuar o comando.`)
  .setColor('#FF0000')
  
message.channel.send(erro6).then(msg => msg.delete({timeout: 5000}))
}

message.author.send(new Discord.MessageEmbed()
  .setDescription(`<:bot:778663236265443349> | Qual é o nome do seu bot?`) 
  .setColor("#003CFF") 
).then(async (a) => {
       let n = message.author.dmChannel.createMessageCollector(x => x.author.id === message.author.id, {max:1})
             .on('collect', async (b) => {
               const nome = b.content
  
            
message.author.send(new Discord.MessageEmbed()
  .setDescription(`<a:processing:756314723560980560> | Qual o ID do seu bot?`) 
  .setColor("#003CFF") 
).then(async (c) => {
       let cp = message.author.dmChannel.createMessageCollector(x => x.author.id === message.author.id, {max:1})
       .on('collect', async (d) => {
          const id = d.content
  
let error7 = new Discord.MessageEmbed()
  .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, Esse BOT não existe.`)
  .setColor('#FF0000')
        
let x = await axios.get(`https://discord.com/api/v8/users/${id}`, {
headers: { Authorization: `Bot ${process.env.TOKEN}` }
}).catch(err => {
 if(err) return message.author.send(error7)
})

  const bot = x.data.bot || false

        let error8 = new Discord.MessageEmbed()
          .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, parece que esse usuário não é um BOT.`)
          .setColor('#FF0000')

  if(bot != true || isNaN(id)) return message.author.send(error8) 

let error9 = new Discord.MessageEmbed()
.setDescription('<a:Noo:757568484086382622> | Você não é meu dono!')
.setColor('#FF0000')

if(id == client.user.id && message.author.id != 639995261967663104) return message.author.send(error9)
 
message.author.send(new Discord.MessageEmbed()
           .setDescription(`<:nodejs:780546909029924894> | Qual é a linguagem de seu BOT?`) 
           .setColor("#003CFF") ).then(async (e) => {
let linguage = message.author.dmChannel.createMessageCollector(x => x.author.id === message.author.id, {max:1}).on('collect', async (f) => {
          const linguagem = f.content
          let error10 = new Discord.MessageEmbed()
          .setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, linguagem inválida.`)
          .setColor('#FF0000')
          if(linguagem.toLowerCase() != 'javascript' && linguagem.toLowerCase() != 'python' && linguagem.toLowerCase() != 'dbd') return message.author.send(error10)
                
                  
          message.author.send(new Discord.MessageEmbed()
           .setDescription(`<:Info:772480355293986826> | Adicione uma info ao seu BOT.`) 
           .setColor("#003CFF") ).then(async (g) => {
       let inf = message.author.dmChannel.createMessageCollector(x => x.author.id === message.author.id, {max:1})
       .on('collect', async (h) => {
          const info = h.content
          
          message.author.send(new Discord.MessageEmbed()
            .setDescription(`📌 | Qual é o prefix do seu bot?`) 
            .setColor("#003CFF") ).then(async (i) => {
             let p = message.author.dmChannel.createMessageCollector(x => x.author.id === message.author.id, {max:1})
             .on('collect', async (j) => {
               const prefix = j.content

           message.author.send(new Discord.MessageEmbed()
             .setDescription('<a:yes:757568594841305149> | Seu BOT foi enviado para a verificação, aguarde os resultados!') 
   .setColor("#24FF00"))

axios.get(`https://discord.com/api/v8/users/${id}`, { 
headers:{ Authorization: `Bot ${process.env.TOKEN}` }
}).then(async (x) => {
  let embed3 = new Discord.MessageEmbed()
  .setThumbnail(`https://cdn.discordapp.com/avatars/${id}/${x.data.avatar}.png?size=2048`)
  .setDescription(`O usuário \`${message.author.tag}\` enviou o BOT \`${x.data.username}#${x.data.discriminator}\` para verificação.`)
  .setColor('#003CFF')
  
  if(message.guild.channels.cache.get(log)) {
    message.guild.channels.cache.get(log).send(embed3)
  } else {
    message.guild.channels.cache.get(correio).send(embed3)
  }
})

axios.get(`https://discord.com/api/v8/users/${process.env.BOTID}`, { 
headers:{ Authorization: `Bot ${process.env.TOKEN}` }
}).then(async (x) => {
  
          let embed5 = new Discord.MessageEmbed()
               .setTitle('Alguem adicionou um BOT!')
               .setThumbnail(`https://cdn.discordapp.com/avatars/${process.env.BOTID}/${x.data.avatar}.png?size=2048`)
               .setColor('#24FF00')
               .setDescription(`<:bot:778663236265443349> | Nome do BOT: \`${nome}\`\n<:Info:772480355293986826> | Info: \`${info}\`\n📌 | Prefixo: \`${prefix}\`\n<:usuario:779001330328403978> | Quem mandou: \`${message.author.tag}\`\n<:convite:778664289913405501> | Convite do bot: [Clique aqui](https://discord.com/oauth2/authorize?client_id=${id}&scope=bot&permissions=0)`)
               .setTimestamp()
               .setFooter('BOT recebido')
               let cargov = await db.ref(`Servers/${message.guild.id}/Configurações/CargoVerificador`).once('value')
               cargov = cargov.val()
               if(!cargov) cargo = ''
               if(cargov) cargov = `<@&${cargov}>`
if(message.guild.channels.cache.get(correio)) { 
  client.channels.cache.get(correio).send(cargov, embed5) 
  } else {
    client.channels.cache.get(log).send(cargov, embed5)
  }
})
          
db.ref(`Servers/${message.guild.id}/BOTs/${id}`).update({ Dono: message.author.id })
db.ref(`Servers/${message.guild.id}/BOTs/${id}`).update({ Info: info })
db.ref(`Servers/${message.guild.id}/BOTs/${id}`).update({ Prefix: prefix })
db.ref(`Servers/${message.guild.id}/BOTs/${id}`).update({ Linguagem: linguagem.toLowerCase() })
db.ref(`Servers/${message.guild.id}/BOTs/${id}`).update({ Queue: 'sim'})
db.ref(`Servers/${message.guild.id}/BOTs/${id}`).update({ Votos: '0' })
db.ref(`Servers/${message.guild.id}/Usuários/${message.author.id}`).update({ ID: id })
db.ref(`Servers/${message.guild.id}/Usuários/${message.author.id}`).update({ Dev: 'sim' })
                        })
                      })
                    })
                  })
                })
              })
            })
          })
        })
      })
      }
    }

  if(message.content.startsWith(prefix)) {
    let log = client.channels.cache.get('768171390247370782')
    let embed = new Discord.MessageEmbed()
    .setAuthor(`${message.guild.name} (${message.guild.owner.user.tag})`, message.guild.iconURL({dynamic: true}))
    .setThumbnail(message.author.avatarURL({dynamic: true}))
    .setDescription(`<:comando:784078028174786571> | Comando: \`${message.content}\`\n<:usuario:779001330328403978> | Comando por: \`${message.author.tag}\` (\`${message.author.id}\`)\n<a:server:784077178559135744> | Nome do server: \`${message.guild.name}\` (\`${message.guild.id}\`)\n<:canal_de_texto:746060909243531375> | Canal: \`${message.channel.name}\` (\`${message.channel.id}\`)`)
    .setColor('#003CFF')
    log.send(embed)
  }
    
    const args = message.content
        .trim().slice(prefix.length)
        .split(/ +/g);
    const commandName = args.shift().toLowerCase()
  
	const command = client.commands.get(commandName) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

	if (!command) return;

if(message.channel.type == 'dm') return;
  
	if (!cooldowns.has(command.name)) {
		cooldowns.set(command.name, new Discord.Collection())
	}

	const now = Date.now()
	const timestamps = cooldowns.get(command.name)
	const cooldownAmount = (command.cooldown || 3) * 1000

	if (timestamps.has(message.author.id) && message.author.id != 639995261967663104) {
		const expirationTime = timestamps.get(message.author.id) + cooldownAmount
		
		if(now < expirationTime) {
			let timeLeft = (expirationTime - now) / 1000
      let sh = 'segundo(s) para executar este comando.'
      if(command.name == 'votar') {
  sh = 'hora(s) para votar.'
  timeLeft = timeLeft / 3600
}
		
			let cooldown_embed = new Discord.MessageEmbed()
			.setDescription(`<a:Noo:757568484086382622> | Desculpe ${message.author}, você precisa esperar ${timeLeft.toFixed(2)} ${sh}`)
			.setColor('#FF0000')
			
return message.channel.send(cooldown_embed)
		}
	}
	if(command.name == 'votar') {
let bot = message.mentions.users.first()
if(bot && bot.bot == true) {
  let dono = await db.ref(`Servers/${message.guild.id}/BOTs/${bot.id}/Dono`).once('value')
  dono = dono.val()
  if(dono) {
	timestamps.set(message.author.id, now)
	setTimeout(() => timestamps.delete(message.author.id), cooldownAmount)
        }
		  }
	 } else {
  timestamps.set(message.author.id, now)
	setTimeout(() => timestamps.delete(message.author.id), cooldownAmount)
	 }
    
    try {
		command.run(client, message, args)
	} catch (error) {
		console.error(`[ \u001b[91mERROR\u001b[39m ] Aconteceu um error, o comando foi ${commandName}! ${error}`)
let embed = new Discord.MessageEmbed()
.setDescription(`Oops! parece que aconteceu um error ao executar esse comando! Reporte [aqui](https://discord.gg/kR8ydvQRVG)! \`${error}\``)
.setColor('#FF0000')
    message.channel.send(embed)
	}
})

client.on('guildDelete', (guild) => {
db.ref(`Servers/${guild.id}`).set(null)
})
 
client.on('ready', () => {

let img = [
`https://cdn.discordapp.com/icons/739362372082335825/36efb8d50fbd2f572e65a7caaf25789f.png?size=1024`,
`https://cdn.discordapp.com/attachments/736079141148950628/759896484861706250/Screenshot_20200927-1856501.png`,
`https://cdn.discordapp.com/attachments/759217940268318730/759550172308439090/invertido.png`,
`https://cdn.discordapp.com/attachments/736079141148950628/759895920774610994/Screenshot_20200927-1854301.png`,
`https://cdn.discordapp.com/attachments/759897199949119540/761269302161834024/Screenshot_20201001-1328131.png`,
`https://cdn.discordapp.com/attachments/759897199949119540/761269301788934154/Screenshot_20201001-1328211.png`,
`https://cdn.discordapp.com/attachments/759897199949119540/761269302455959572/Screenshot_20201001-1328301.png`,
`https://cdn.discordapp.com/attachments/765641605972754473/765641652110491658/20201013_124615.jpg`,
`https://cdn.discordapp.com/attachments/765641605972754473/765641652445642792/20201013_124405.jpg`,
`https://cdn.discordapp.com/attachments/759897199949119540/761269302727802930/Screenshot_20201001-1328261.png`,
`https://cdn.discordapp.com/attachments/759217940268318730/759550033812258846/dinoAvatar.png`,
`https://cdn.discordapp.com/attachments/759897199949119540/761269303097950269/Screenshot_20201001-1328181.png`,
`https://cdn.discordapp.com/avatars/720363449057804308/8238f80416c58fb4b1209df30a7aca8e.png?size=1024`

 ]
let avatars = [
    'https://i.imgur.com/h1cJ04l.png',
    'https://i.imgur.com/ufkpjtl.png',
    'https://i.imgur.com/Svo9KCd.png',
    'https://i.imgur.com/YQdfJIL.png',
    'https://i.imgur.com/VkOiZAm.png'
]  
let statusB = [
  { 
    mensagem: 'Me convide! ??invite', 
    status: 'idle'
  },
  { 
    mensagem: 'Sempre te ajudando!', 
    status: 'idle'
  },
  { 
    mensagem: 'Sempre tenho updates e melhorias!', 
    status: 'dnd'
  },
  ]
 function imgs() {
 let randomImage = img[Math.floor(Math.random() * img.length)]
 client.guilds.cache.get('739362372082335825').setIcon(randomImage)
 }
 function avatares() {
     let randomAvatar = avatars[Math.floor(Math.random() * avatars.length)]
     client.user.setAvatar(randomAvatar)
} 
function status() {
let randomStatus = statusB[Math.floor(Math.random() * statusB.length)]
client.user.setPresence({activity: { name: randomStatus.mensagem }, status: randomStatus.status})
  .then(console.log(`[ \u001b[92mSISTEMA\u001b[39m ] Mudei meu status com sucesso! ${randomStatus.mensagem} e ${randomStatus.status}`))
  .catch(err => console.log(`[ \u001b[91mERROR\u001b[39m ] Não foi possível setar meu status! ${err}`))
}
 setInterval(() => imgs(), 1000 * 60 * 2)
 setInterval(() => avatares(), 1000 * 60 * 10)
 setInterval(() => status(), 1000 * 30)
})

client.on('guildMemberRemove', async (member) => {
try {
let dono = await db.ref(`Servers/${member.guild.id}/${member.user.id}/Dono`).once('value')
dono = dono.val()
      if(member.user.bot) {
        if(!dono) return;
        console.log("dono " + dono)
    let embed = new Discord.MessageEmbed()
      .setDescription(`<:KickBot:778670531960242178> | O BOT \`${client.users.cache.get(member.id).tag} (${member.id})\` foi deletado da database por sair do server.`)
      .setColor('#FF0000')
      
let log = await db.ref(`Servers/${member.guild.id}/Configurações/CanalLog`).once('value')
     log = log.val()
     
    if(log) { client.channels.cache.get(log).send(embed) }
    
         db.ref(`Servers/${member.guild.id}/${member.user.id}`).set(null)
         db.ref(`Servers/${member.guild.id}/${dono}`).set(null)
         console.log(id)
       } else {
         
  let id = await db.ref(`Servers/${member.guild.id}/${member.user.id}/ID`).once('value')
  id = id.val()
  
  console.log("id " + id)
  
  if(!id) return;
  
         db.ref(`Servers/${member.guild.id}/${member.user.id}`).set(null)
         db.ref(`Servers/${member.guild.id}/${id}`).set(null)
         
  let sistema = await db.ref(`Servers/${member.guild.id}/Configurações/SistemaKick`).once('value')
  sistema = sistema.val()
  
  if(sistema != 'sim') return;
  
   let dev = await db.ref(`Servers/${member.guild.id}/${member.user.id}/Dev`).once('value')
     dev = dev.val()
     
    if(dev != 'sim') return;
         
    let bot = client.users.cache.get(id)
    
    if(member.guild.me.hasPermission('KICK_MEMBERS')) {
      member.guild.members.cache.get(id).kick()
    }
    
    let embed = new Discord.MessageEmbed()
    .setTitle('BOT kickado')
    .setThumbnail(client.user.avatarURL({dynamic: true})) 
    .setDescription(`<:KickBot:778670531960242178> | O BOT ${bot.tag} foi kickado automáticamente por dono ter saído do server.`)
    .setFooter('Kick')
    .setTimestamp()
    .setColor('#FF0000')

let log = await db.ref(`Servers/${member.guild.id}/Configurações/CanalLog`).once('value')
     log = log.val()

  client.channels.cache.get(log).send(embed)
}
} catch(err) {
  console.log(`[ \u001b[91mERROR\u001b[39m ] Aconteceu um error no sistema de kick! ${err}`)
}
})
 
 client.on('guildMemberAdd', async (member) => {
  let autoroleB = await db.ref(`Servers/${member.guild.id}/Configurações/AutoroleBot`).once('value')
   autoroleB = autoroleB.val()
   
  let autoroleU = await db.ref(`Servers/${member.guild.id}/Configurações/AutoroleUser`).once('value')
   autoroleU = autoroleU.val()
   if(member.user.bot && autoroleB) {
   member.roles.add(autoroleB)
   }
   
   if(!member.user.bot && autoroleU) {
   member.roles.add(autoroleU)
   }
 })